from project.task import Task


class Section:
    def __init__(self, name: str):
        self.name = name
        self.tasks = []

    def add_task(self, new_task: Task):
        self.tasks.append(new_task)
        return f"Task {Task.details(new_task)} is added to the section"

    def complete_task(self, task_name: str):
        for t in self.tasks:
            if task_name == t.name:
                t.completed = True
                return f"Completed task {task_name}"
            return f"Could not find task with the name {task_name}"

    def clean_section(self):
        cleared_tasks = 0
        for t in self.tasks:
            if t.completed:
                self.tasks.remove(t)
                cleared_tasks += 1
        return f"Cleared {cleared_tasks} tasks."

    def view_section(self):
        result = [f'Section {self.name}:']
        for t in self.tasks:
            result.append(t.details())
        return '\n'.join(result)

